<?php
	// About
	/* 
	   This script calls the EHCP API and sets webserver to apache2
	   By:  earnolmartin@gmail.com 
	   www.ehcpforce.tk
	*/

	/* EHCP API Call */
        $curDir = getcwd();

        if(chdir("/var/www/new/ehcp/")){
            require ("classapp.php");
            $app = new Application();
            $app->connectTodb(); # fill config.php with db user/pass for things to work..
            
            // Set server type to apache2
            $app->setConfigValue('webservertype','apache2');
            
            // Fix apache configs
            $app->addDaemonOp('rebuild_webserver_configs','','','','rebuild_webserver_configs');

        }

        chdir($curDir);
        /* END EHCP API Call */
	

?>
