<?php

/**
 * Theme description
 *
 * @copyright 2004-2024 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version $Id: theme.php 15008 2024-01-02 22:42:19Z pdontthink $
 * @package squirrelmail
 * @subpackage themes
 */
$icon_themes[] = array('NAME'=>_("XP"),'PATH'=> SM_PATH . 'images/themes/xp/');
