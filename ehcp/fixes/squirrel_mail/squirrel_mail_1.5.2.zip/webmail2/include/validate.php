<?php

/**
 * validate.php
 *
 * @copyright 1999-2024 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version $Id: validate.php 15008 2024-01-02 22:42:19Z pdontthink $
 * @package squirrelmail
 */

echo "Rewrite your code, we now use init.php";
die();
?>