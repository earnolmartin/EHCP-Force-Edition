<?php

/**
 * Theme description
 *
 * @copyright 2004-2020 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version $Id: theme.php 14845 2020-01-07 08:09:34Z pdontthink $
 * @package squirrelmail
 * @subpackage themes
 */
$icon_themes[] = array('NAME'=>_("Default"),'PATH'=> SM_PATH.'images/themes/default/');
