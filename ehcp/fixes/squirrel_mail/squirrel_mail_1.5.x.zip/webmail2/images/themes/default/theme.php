<?php

/**
 * Theme description
 *
 * @copyright 2004-2023 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version $Id: theme.php 14986 2023-01-03 02:11:29Z pdontthink $
 * @package squirrelmail
 * @subpackage themes
 */
$icon_themes[] = array('NAME'=>_("Default"),'PATH'=> SM_PATH.'images/themes/default/');
