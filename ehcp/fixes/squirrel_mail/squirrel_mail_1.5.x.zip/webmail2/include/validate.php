<?php

/**
 * validate.php
 *
 * @copyright 1999-2023 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version $Id: validate.php 14986 2023-01-03 02:11:29Z pdontthink $
 * @package squirrelmail
 */

echo "Rewrite your code, we now use init.php";
die();
?>