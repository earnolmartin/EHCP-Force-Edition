<?php

/**
 * index.php
 *
 * Redirects to the index.html file.
 *
 * @copyright 1999-2023 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version $Id: index.php 14986 2023-01-03 02:11:29Z pdontthink $
 * @package squirrelmail
 */

header('Location: index.html');

