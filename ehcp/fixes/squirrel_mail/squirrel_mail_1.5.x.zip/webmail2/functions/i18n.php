<?php
/**
 * old i18n function file location
 *
 * @copyright 1999-2020 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version $Id: i18n.php 14845 2020-01-07 08:09:34Z pdontthink $
 * @package squirrelmail
 */

/** break if somebody tries to load this file */
die('Rewrite your code, functions/i18n.php file location is changed in 1.5.2.'
    .' Direct loading of functions/i18n.php is deprecated.');
?>