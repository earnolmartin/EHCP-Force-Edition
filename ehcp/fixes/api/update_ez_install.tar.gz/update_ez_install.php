<?php
	// About
	/* 
	   This script calls the EHCP API and runs a domain sync after upgrading EHCP so that the domains, subdomains, and other apache2 configs are regenerated properly
	   By:  earnolmartin@gmail.com 
	   www.ehcpforce.tk
	*/

	/* EHCP API Call */
        $curDir = getcwd();

        if(chdir("/var/www/new/ehcp/")){
            require ("classapp.php");
            $app = new Application();
            $app->connectTodb(); # fill config.php with db user/pass for things to work..

            $app->addDaemonOp("update_ez_install", '', 'xx', '', 'Update EZ Script Install SQL');
        }

        chdir($curDir);
        /* END EHCP API Call */
	

?>
