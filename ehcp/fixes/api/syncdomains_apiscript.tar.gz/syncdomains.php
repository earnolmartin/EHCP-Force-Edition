<?php
	// About
	/* 
	   This script calls the EHCP API and rebuilds the webserver templates used for the selected web server software configured in the panel settings (nginx or apache2)
	   It then syncs all domains to use the proper templates
	   By:  earnolmartin@gmail.com 
	   www.ehcpforce.tk
	*/

	/* EHCP API Call */
        $curDir = getcwd();

        if(chdir("/var/www/new/ehcp/")){
            require ("classapp.php");
            $app = new Application();
            $app->connectTodb(); # fill config.php with db user/pass for things to work..
            $app->addDaemonOp('rebuild_webserver_configs','','','','rebuild_webserver_configs');
        }

        chdir($curDir);
        /* END EHCP API Call */
	

?>
