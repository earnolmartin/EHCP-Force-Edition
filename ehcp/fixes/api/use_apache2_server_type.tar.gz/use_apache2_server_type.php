<?php
	// About
	/* 
	   This script calls the EHCP API, resets all global custom webserver templates, and rebuilds domain configuration files, and restarts the webserver.
	   By:  earnolmartin@gmail.com 
	   www.ehcpforce.tk
	*/

	/* EHCP API Call */
        $curDir = getcwd();

        if(chdir("/var/www/new/ehcp/")){
            require ("classapp.php");
            $app = new Application();
            $app->connectTodb(); # fill config.php with db user/pass for things to work..
            $app->loadConfig(); # Load config
            $app->setConfigValue("webservertype","apache2");
        }

        chdir($curDir);
    /* END EHCP API Call */

?>
