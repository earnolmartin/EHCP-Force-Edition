<?php
	// About
	/* 
	   This script can be used to create an empty database under the EHCP mysql user only, 
	   or it can be used to create a database under the EHCP mysql user and then run a sql file to populate that database.
	   
	   Arguments:
		* script.php $1 $2
		* $1 = name of database to create
		* $2 = sql file path to populate database with (optional) [Can be full or relative path to /var/www/new/ehcp]
	   
	   
	   By:  earnolmartin@gmail.com 
	   www.ehcpforce.tk
	   
	*/

	
		if(count($argv) > 1){
			$dbnameToCreate = $argv[1];
			if(isset($argv[2])){
				$sqlFileToRunAfter = $argv[2];
			}
			$curDir = getcwd();

			if(chdir("/var/www/new/ehcp/")){
				/* EHCP API Call */
				require ("classapp.php");
				$app = new Application();
				$app->connectTodb(); # fill config.php with db user/pass for things to work..
				$app->loadConfig();
				// Get the webserver type
				//exit(strtolower($app->miscconfig['webservertype']));
				$ehcpmysqlpass = $app->dbpass;
				$ehcpuser = $app->dbusername;
				$mysqlInfo = $app->getMysqlServer('',false,__FUNCTION__);
				if(!empty($ehcpmysqlpass) && !empty($ehcpuser) && !empty($mysqlInfo["pass"]) && !empty($dbnameToCreate)){
					$filecontent="
						drop database if exists " . $dbnameToCreate . ";
						create database " . $dbnameToCreate . ";
						grant all privileges on " . $dbnameToCreate . ".* to ehcp@'localhost' identified by '$ehcpmysqlpass' with grant option;
						grant all privileges on " . $dbnameToCreate . ".* to ehcp@'127.0.0.1' identified by '$ehcpmysqlpass' with grant option;
						grant all privileges on " . $dbnameToCreate . ".* to ehcp@'127.0.1.1' identified by '$ehcpmysqlpass' with grant option;
					";
					$file = "tempsql.sql";
					$handle = fopen($file, "w+");
					fwrite($handle, $filecontent);
					fclose($handle);

					passthru("mysql -u root --password=" . $mysqlInfo["pass"] . " < $file"); # root pass changes here... if different , disabled
					unlink($file);
					
					if(!empty($sqlFileToRunAfter)){
						if(file_exists($sqlFileToRunAfter)){
							passthru("mysql -u ehcp --password=" . $ehcpmysqlpass . " " . $dbnameToCreate . " < " . $sqlFileToRunAfter);
						}
					}
				}
				/* END EHCP API Call */
			}
			chdir($curDir);
		}
        
	
		

?>
