<?php
	// About
	/* 
	   This script will return the web server type from the panel to a bash script variable
	   By:  earnolmartin@gmail.com 
	   www.ehcpforce.tk
	*/

	/* EHCP API Call */
        $curDir = getcwd();

        if(chdir("/var/www/new/ehcp/")){
            require ("classapp.php");
            $app = new Application();
            $app->connectTodb(); # fill config.php with db user/pass for things to work..
            $app->loadConfig();
            // Get the webserver type
            exit(strtolower($app->miscconfig['webservertype']));
        }

        chdir($curDir);
        /* END EHCP API Call */
	

?>
